#ifndef NODOLSOR_H
#define NODOLSOR_H


class NODOLSOR
{
    public:
        NODOLSOR();
        virtual ~NODOLSOR();

    protected:

    private:
};

#endif // NODOLSOR_H
