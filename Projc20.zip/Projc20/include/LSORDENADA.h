#ifndef LSORDENADA_H
#define LSORDENADA_H


class LSORDENADA
{
    public:
        LSORDENADA();
        virtual ~LSORDENADA();

    protected:

    private:
};

#endif // LSORDENADA_H
