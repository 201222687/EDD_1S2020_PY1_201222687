#include "NODOLDEJUGA.h"

NODOLDEJUGA::NODOLDEJUGA(string letra, int puntajeletra)
{
    this->letra=letra;
    this->puntajeletra=puntajeletra;
    this->Siguiente=NULL;
    this->Anterior=NULL;
}

