#include "cabezanodoldec.h"


cabezanodoldec::cabezanodoldec(int dato)
{
  this->dato=dato;
  this->anterior=NULL;
  this->siguiente=NULL;
  this->accesonodoortogonal=NULL;
}
