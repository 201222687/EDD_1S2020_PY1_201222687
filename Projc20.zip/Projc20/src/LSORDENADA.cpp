#include "LSORDENADA.h"

LSORDENADA::LSORDENADA()
{
    //ctor
}

LSORDENADA::~LSORDENADA()
{
    //dtor
}
