#include "Terminal.h"

Terminal::Terminal(string valor)
{
    this->valor=valor;
    this->AccesoDerechaLDEC=NULL;
    this->AccesoAbajoLDEC=NULL;
}
