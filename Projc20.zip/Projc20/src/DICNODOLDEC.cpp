#include "DICNODOLDEC.h"


DICNODOLDEC::DICNODOLDEC(string palabra)
{
  this->palabra=palabra;
  this->anterior=NULL;
  this->siguiente=NULL;
}
